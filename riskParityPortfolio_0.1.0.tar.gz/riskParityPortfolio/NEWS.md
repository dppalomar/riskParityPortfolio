# riskParityPortfolio 0.1.0: 2018-12-15

* Initial release version 0.1.0 is on CRAN.
